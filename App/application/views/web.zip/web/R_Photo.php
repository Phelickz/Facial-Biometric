<?php include("include/header.php") ?>
<?php include("include/nav-header.php") ?>
<?php include("include/nav-bar.php") ?>
<?php 

 foreach ($dataDD as $key) {
         $clasID= $key["r_classID"];
         $Score= $key["Score"];
         $class= $key["classID"];
          $KeyID = $key["KeyID"];
         $date_log= $key["date_log"];
        }
      $classDD=json_decode($clasID);
     $ScoreDD=json_decode($Score);

       // foreach ($dc as $v) {
       //   echo $v."<br>";
       //  }


?>
<!-- Page content -->
            <div id="page-content-wrapper"  ng-app="myStock" ng-controller="StockCtrl" ng-init="show_data()">


                <div class="page-content">
                    <!-- Content Header (Page header) -->
                    <section class="content-header">
                        <div class="header-icon">
                            <i class="fa fa-id-badge"></i>
                        </div>
                        <div class="header-title">
                            <h1> BIOMETRIC PHOTOS</h1>
                            <small>BIOMETRIC PHOTOS features</small>
                            <ul class="link hidden-xs">
                                <li><a href=""><i class="fa fa-home"></i>Home</a></li>
                                <li><a href="<?=base_url()?>Report/BioLog">Bio Log</a></li>
                            </ul>
                        </div>
                    </section>


<!-- page section -->
                    <div class="container-fluid">
                        <div class="row">
                            <div class="mail-box">
                                <aside class="sm-side hidden-xs">
                                    <div class="user-head">
                                        <a class="inbox-avatar">
                                            <img src="<?= base_url() ?>assets/web/dist/img/avatar5.png" class="border-green" width="60" height="50" alt="logo">
                                        </a>
                                        
                                    </div>
                                    <div class="inbox-body">
                                        <a href="" class="btn btn-compose">
                                           <?=$date_log?>
                                        </a>
                                    </div>
                                  
                                    
                                </aside>
                                <aside class="lg-side">
                                    <div class="inbox-head">
                                        <h3>BIOMETRIC MATCH RECORD</h3>
                                        <form action="#" class="pull-right position">
                                            <div class="input-append">
                                                <input type="text" class="sr-input" placeholder="Search Mail">

                                            </div>
                                        </form>
                                    </div>
                                    <div class="inbox-body">
                                       <div class="col-md-6">
                                        <table class="table table-bordered table-hover table-responsive">
                                            <tbody>
                                              <?php foreach ($classDD as $KeyClass):?>
                                                <tr class="unread" id="tabl">
                                                  
                                                    <td class="view-message"><?=$KeyID.$KeyClass?></td>
                                                    
                                                </tr> 
                                              <?php endforeach;?>

                                            </tbody>
                                        </table>
                                        </div>
                                        <!--score-->
                                        <div class="col-md-6">
                                        <table class="table table-bordered table-hover table-responsive">
                                            <tbody>
                                              <?php foreach ($ScoreDD as $KeyScore):?>
                                                <tr class="unread" id="tabl">
                                                  
                                                    <td class="view-message"><?=$KeyScore?></td>
                                                    
                                                </tr> 
                                              <?php endforeach;?>

                                            </tbody>
                                        </table>
                                        </div>


                                    </div>
                                </aside>
                            </div>

                        </div>
                        <!-- ./row -->
                    </div>
                    <!-- ./cotainer -->
                </div>
                <!-- ./page-content -->
            </div>
            <!-- ./page-content-wrapper -->
        </div>
        <!-- ./page-wrapper -->

   
            <?php include("include/footer.php") ?>
               
            
           