// JavaScript Document
//alert("Veripay Face Dector Ready ")
var CLASS_ID =Math.floor((Math.random() * 600666666) + 1);
        localStorage.setItem("CLASS_IDD", CLASS_ID);
		console.log(localStorage.getItem("CLASS_IDD"))
